package com.example.ex12;

public class Address {
    String name;
    String add;

    //데이터 생성 메소드
    public Address(String name, String add) {
        this.name = name;
        this.add = add;
    }
}
