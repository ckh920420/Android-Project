package com.example.ex11;

public class Address {
    int img;
    String name;
    String tel;
    String add;

    public Address(int img, String name, String tel, String add) {
        this.img = img;
        this.name = name;
        this.tel = tel;
        this.add = add;
    }
}
